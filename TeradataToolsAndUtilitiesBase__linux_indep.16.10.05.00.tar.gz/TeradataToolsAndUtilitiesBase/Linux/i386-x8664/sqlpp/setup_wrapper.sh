#!/bin/sh
#******************************************************************************
#*
#*    TITLE: setup_wrapper.sh                            16.00.05.00
#*
#*    Copyright Teradata Corporation 2014-2017.  All rights reserved.
#*
#*    This shell script is used to provide the prefix when installing
#*    a package. It will then launch the rpm found in the same location
#*    with the prefix from an existing installed package of the same short
#*    version or the one entered by the user if we did not find an installed
#*    of the same short version.
#*
#* History:
#*
#* 15.00.00.00 07112014 AW186011 CLNTINS-4595 Create the script
#* 15.10.01.00 04222015 PP121926 CLNTINS-4595 Fixes
#* 15.10.01.00 07102015 AW186011 CLNTINS-5479 Fix issue with invalid prefix
#* 15.10.01.00 09162015 RM185040 CLNTINS-5735 Modify to use getopts.
#* 16.00.01.00 12072016 PK186046 CLNTINS-7169 Update setup_wrapper.sh to use 
#*                                            --replaceFiles
#* 16.00.05.00 03022017 PK186046 CLNTINS-7515 setup_wrapper.sh throws error
#*                                            while trying to install pkgs.
#*
#******************************************************************************

#-----------------------------------------------------------------------
# Function: usage
#
# Description: Displays usage/help information.
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------
usage ()
{
  ${display_cmd} "\n  setup_wrapper.sh: usage: setup_wrapper.sh [-i <installation directory>] [-r <rpm to install>] [-h] [-s]" 
  ${display_cmd} "\n                           -i: takes an installation directory as its argument."
  ${display_cmd} "\n                           -r: takes an rpm to install, from the current directory, as its argument."
  ${display_cmd} "\n                           -s: turns on silent installation."
  ${display_cmd} "\n                           -h: provides usage information.\n\n"
}

#-----------------------------------------------------------------------
# Function: initialize_variables
#
# Description: Initializes all variables necessary for this installation.
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------
initialize_variables ()
{
  # WARNING!!! The first two variables need to be modified every release until automated.
  CRYEAR="2017"
  SCRIPTVER="16.00.05.00"

  OS=`uname -s`
  thisuser=`eval whoami`
  SYSTEMPACKAGESOUT="/tmp/ttu-systempackagesout-$$.out"
  installCfg=/var/opt/teradata/ttu_install.cfg

  major=`echo "${SCRIPTVER}" | cut -d '.' -f 1`
  minor=`echo "${SCRIPTVER}" | cut -d '.' -f 2`
  VERSION_DISPLAY="${major}""${minor}"
  VERSION_INSTALL="${major}"."${minor}"

  ask_user=1
  ask_user_instdir=1
  found_prefix_config_file=0
  found_prefix_commandline=0
  user_choice="NULL"
  display_cmd="printf"
}

#-----------------------------------------------------------------------
# Function: display_screen
#
# Description: Displays the initial installation screen.
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------
display_screen ()
{
  ${display_cmd} "\n"${line_display}""
  ${display_cmd} "\nInstall mode chosen is - "${mode_text}""
  ${display_cmd} "\n"${line_display}"\n"
}

#-----------------------------------------------------------------------
# Function: read_config_file
#
# Description: Reads the install config file located at
#              /var/opt/teradata/ttu_install.cfg
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------
read_config_file ()
{
  if [ ! -f "$installCfg" ]
  then
    unset installCfg

#     CFGPATH=`printenv TTU_INSTALL_CFG`
#     the above does not work in a /bin/ksh

    CFGPATH=`eval echo '$'TTU_INSTALL_CFG`
    if [ "$CFGPATH" != "" ]
    then
    # Replace colons with spaces to create list.

      for path in ${CFGPATH//:/ }; do
         installCfg=$path/ttu_install.cfg
         if [ -f $installCfg ]
         then
           ${display_cmd} "The install configuration file is $installCfg"
           break;
         else
           unset installCfg
         fi
      done
    fi
  fi

  if [ -f "$installCfg" ]
  then
    installDir=`grep -i -F "InstallPrefix=" $installCfg`
    if [ "$?" = "0" ]
    then
       TTU_INST_DIR=`echo $installDir | sed 's/.*=//'`
       ask_user_instdir=0
       found_prefix_config_file=1
       prefix_gather_mode="installation configuration file"
    fi
  fi
}

#-----------------------------------------------------------------------
# Function: check_silent_or_interactive
#
# Description: Takes action based on mode of installation chosen by user.
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------
check_silent_or_interactive ()
{
  if [ "${silent}" = "1" ]
  then
     ask_user=0
     ask_user_instdir=0
     mode_text="Silent"
     line_display="-------------------------------"
     check_for_commandline_prefix
     if [ "${found_prefix_commandline}" = "0" ]
     then
       read_config_file
     fi
  else
     mode_text="Interactive"
     line_display="------------------------------------"
     check_for_commandline_prefix
     if [ "${found_prefix_commandline}" = "0" ]
     then
       read_config_file
     fi
  fi
}

#-----------------------------------------------------------------------
# Function: check_for_commandline_prefix
#
# Description: Checks if the user has provided a prefix using "-i".
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------
check_for_commandline_prefix ()
{
  if [ ! -z "${install_prefix}" ]
  then
    TTU_INST_DIR="${install_prefix}"
    ask_user_instdir=0
    found_prefix_commandline=1
    prefix_gather_mode="commandline option \"-i\""
  fi
}

#-----------------------------------------------------------------------
# Function: validate_user_choice
#
# Description: Makes sure user inputs are valid.
#
# Input: $1 = input provided by user.
#        $2 = default value for the particular invocation.
#
# Output: Nil
#-----------------------------------------------------------------------
validate_user_choice ()
{
  user_choice=$1
  default=$2
  while [[ "$user_choice" != "Y" && "$user_choice" != "y" && "$user_choice" != "N" && "$user_choice" != "n" && "$user_choice" != "" ]]
  do
    ${display_cmd} "\n Unrecognized input! Please enter [Y/y] or [N/n] only (default: \""$default"\"): "
    read user_choice
  done
}

#-----------------------------------------------------------------------
# Function: check_prefix
#
# Description: Makes sure prefixes are set right for installation.
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------
check_prefix ()
{
  installed_all_pkgs=`/bin/rpm -qa | egrep "(arc|cliv2|tptbase|tptstream|bteq|piom|npaxsmod|mqaxsmod|jmsaxsmod|mload|fastexp|fastld|tpump|sqlpp|tdwallet|tdicu|teragss)${VERSION_DISPLAY}"`
  installed_all_pkgs=`echo $installed_all_pkgs | tr -s " " "\n" | grep "${VERSION_INSTALL}"`
  installed_pkg=`echo $installed_all_pkgs | cut -d" " -f1`

  if [ -n "${installed_pkg}" ]; then
    EXISTING_INST_DIR=`rpm -q --queryformat '%{INSTPREFIXES}' ${installed_pkg}`
    if [ -z "${TTU_INST_DIR}" ]
    then
      TTU_INST_DIR="/opt"
    fi
    if [ "${EXISTING_INST_DIR}" != "${TTU_INST_DIR}" ]
    then
      ${display_cmd} "\nFound the following TTU ${VERSION_INSTALL} packages installed in \""${EXISTING_INST_DIR}"\" -"
      ${display_cmd} "\n ${installed_all_pkgs}" | tr -s " " "\n"
      ${display_cmd} "\n\n < All ${VERSION_INSTALL} packages will have to be installed in \""${EXISTING_INST_DIR}"\" >"
      if [ "${ask_user}" = "1" ]
      then
        ${display_cmd} "\n\n Do you wish to continue this installation under \""${EXISTING_INST_DIR}"\"?"
        ${display_cmd} "\n Type [Y/y] to continue, [/N/n] to exit (default: \"y\"): "
        read user_choice
        validate_user_choice "${user_choice}" "y"
        if [[ "${user_choice}" = "n" || "${user_choice}" = "N" ]]
        then
          exit 0
        else
          TTU_INST_DIR="${EXISTING_INST_DIR}"
        fi
      else
        ${display_cmd} "\n\n Aborting installation!"
        ${display_cmd} "\n   Prefix provided using the ${prefix_gather_mode} ("${TTU_INST_DIR}"),"
        ${display_cmd} "\n   does not match with prefix of already existing ${VERSION_INSTALL} packages ("${EXISTING_INST_DIR}").\n"
        exit 1
      fi
    fi
    display_mode="the prefix of already installed TTU ${VERSION_INSTALL} packages"
  else
    if [ "${ask_user}" = "1" ]
    then
      if [ "${ask_user_instdir}" = "1" ]
      then
        ${display_cmd} "\n Please enter an installation directory (default: \"/opt\"): "
        read user_prefix
        if [ -z "${user_prefix}" ]
        then
          display_mode="the default prefix"
          TTU_INST_DIR="/opt"
        else
          display_mode="entered by user"
          TTU_INST_DIR="${user_prefix}"
        fi
      else
        if [ "${found_prefix_commandline}" = "1" ]
        then
          display_mode="provided on the commandline"
        else
          ${display_cmd} "\n Found prefix set to \"${TTU_INST_DIR}\" in install config file \"${installCfg}\""
          ${display_cmd} "\n If you wish to install elsewhere, please enter an installation directory (default: \"${TTU_INST_DIR}\"): "
          read user_prefix
          if [ ! -z "${user_prefix}" ]
          then
            display_mode="entered by user"
            TTU_INST_DIR="${user_prefix}"
          else
            display_mode="provided through config file \"${installCfg}\""
          fi
        fi
      fi
    else
      if [ "${found_prefix_commandline}" = "1" ]
      then
        display_mode="provided on the commandline"
      elif [ "${found_prefix_config_file}" = "1" ]
      then
        display_mode="provided through config file \"${installCfg}\""
      else
        display_mode="the default prefix"
        TTU_INST_DIR="/opt"
      fi
    fi
  fi
}

#-----------------------------------------------------------------------
# Function: invoke_rpm
#
# Description: Performs actual installation.
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------
invoke_rpm ()
{
  rpm_to_install="$1"
  thisuser=`eval whoami`
  ${display_cmd} "\nInstalling "${rpm_to_install}" in \""${TTU_INST_DIR}"\"...\n"
  if [ "${thisuser}" = "root" ]
  then
    rpm -Uvh "${rpm_to_install}" --prefix="${TTU_INST_DIR}" --replacepkgs --replacefiles
  else
    sudo rpm -Uvh "${rpm_to_install}" --prefix="${TTU_INST_DIR}" --replacepkgs --replacefiles
  fi

  if [ "$?" = "1" ]; then
    ${display_cmd} "\n Error! The installation of "${rpm_to_install}" failed.\n"
  fi  
}

#-----------------------------------------------------------------------------------
# Function: install_package
#
# Description: Checks and makes sure everything is good to proceed with installation.
#
# Input: Nil
#
# Output: Nil
#-----------------------------------------------------------------------------------
install_package ()
{
  ${display_cmd} "\n < \""${TTU_INST_DIR}"\", ${display_mode}, will be used as the installation directory. > \n"

  if [ ! -z "${package_name}" ]; then
    package_found=`ls | grep "${package_name}"`
    if [ ! -z "${package_found}" ]; then
      invoke_rpm "${package_name}" 
    else
      ${display_cmd} "Error! Package "${package_name}" not found in current directory. Aborting now!\n"
      usage
      exit 1
    fi
  else
    packages_found=`ls | grep ".rpm" | grep "${VERSION_INSTALL}"`
    packages_found=`echo $packages_found | tr -s " " " "`
    num_packages=`echo "${packages_found}" | wc -w`
    if [ "${num_packages}" -eq 0 ]
    then
      ${display_cmd} "Error! No rpm packages were found in the current directory. Aborting now!\n"
      usage
      exit 1
    elif [ "${num_packages}" -gt 1 ]
    then
      if [ "${ask_user}" = "0" ]
      then
        ${display_cmd} "\n Aborting Installation! ${num_packages} TTU ${VERSION_INSTALL} rpm packages were found in the current directory..."
        ${display_cmd} "\n To install just one package in \""${TTU_INST_DIR}"\", please use the \"-r\" option."
        ${display_cmd} "\n [ Example - \"./setup_wrapper.sh -r <package_to_be_installed>\" ] \n"
        exit 1
      fi
      ${display_cmd} "\n${num_packages} TTU ${VERSION_INSTALL} rpm packages were found in the current directory..."
      ${display_cmd} "\n ${packages_found}" | tr -s " " "\n"
      ${display_cmd} "\n\n To install just one package in \""${TTU_INST_DIR}"\", please exit and use the \"-r\" option."
      ${display_cmd} "\n [ Example - \"./setup_wrapper.sh -r <package_to_be_installed>\" ]"
      ${display_cmd} "\n Type [Y/y] to install all packages in \""${TTU_INST_DIR}"\", or [N/n] to exit (default: \"n\"): "
      read user_choice

      validate_user_choice "${user_choice}" "n"

      if [[ "$user_choice" = "Y" || "$user_choice" = "y" ]] 
      then
        for package_to_install in `echo $packages_found`
        do
          invoke_rpm "${package_to_install}" 
        done
      else
         ${display_cmd} "\n Aborting Installation as per user input!\n"
      fi
    else
      invoke_rpm "${packages_found}" 
    fi
  fi
}

##################################
# Script begins here -
##################################

initialize_variables

while getopts :r:i:sh setup_args
do
  options_found=1
  case $setup_args in
    r) package_name=$OPTARG
       ;;
    i) install_prefix=$OPTARG
       ;;
    s) silent="1"
       ;;
    h) usage
       exit 1
       ;;
    ?) usage
       exit 1
       ;;
  esac
done
shift $(($OPTIND - 1))

check_silent_or_interactive
display_screen
check_prefix
install_package
